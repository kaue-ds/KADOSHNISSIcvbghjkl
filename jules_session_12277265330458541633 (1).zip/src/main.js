import './styles/main.scss'
import './i18n.js'
