// A simple i18n implementation

// 1. Define available languages
const availableLangs = ['es', 'en', 'pt', 'fr'];

// 2. Function to get the preferred language
function getLanguage() {
  const browserLang = navigator.language.split('-')[0];
  return availableLangs.includes(browserLang) ? browserLang : 'es';
}

// 3. Function to load the translations
async function loadTranslations(lang) {
  try {
    const response = await fetch(`/locales/${lang}.json`);
    if (!response.ok) {
      throw new Error(`Failed to load translation file for ${lang}`);
    }
    return await response.json();
  } catch (error) {
    console.error(error);
    // Fallback to Spanish if the requested language fails
    const response = await fetch(`/locales/es.json`);
    return await response.json();
  }
}

// 4. Function to apply the translations to the page
function applyTranslations(translations) {
  const elements = document.querySelectorAll('[data-i18n-key]');
  elements.forEach(element => {
    const key = element.getAttribute('data-i18n-key');
    if (translations[key]) {
      element.innerHTML = translations[key];
    }
  });
}

// 5. Main function to initialize the translation
async function initI18n() {
  const lang = getLanguage();
  const translations = await loadTranslations(lang);
  applyTranslations(translations);
}

// 6. Run the initialization
initI18n();
